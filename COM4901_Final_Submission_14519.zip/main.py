"""
main.py
Main Pipeline Orchestrator for Machine Learning-Based Hybrid Intrusion Detection System for IoT Networks.
Executes Stages 1-8, generates empirical tables, zero-day simulation results, and publication plots.
"""

import os
import json
import time
import pandas as pd
import numpy as np
from sklearn.metrics import recall_score

from data_loader import load_and_preprocess_data
from feature_selection import run_feature_selection
from signature_engine import SignatureEngine
from ml_models import train_and_evaluate_models
from hybrid_ids import HybridIDS
from evaluator import evaluate_system_performance, format_metrics_table
from visualizer import generate_all_visualizations

def run_main_pipeline():
    output_dir = "output"
    os.makedirs(output_dir, exist_ok=True)
    
    print("=" * 75)
    print("  HYBRID INTRUSION DETECTION SYSTEM (HIDS) FOR IOT NETWORKS - PIPELINE")
    print("=" * 75)

    # STAGE 1: Load & Preprocess Data
    print("\n--- STAGE 1: Data Ingestion & Preprocessing ---")
    X_train, X_test, y_train, y_test, cat_train, cat_test, all_features = load_and_preprocess_data()

    # STAGE 2: 3-Stage Feature Selection
    print("\n--- STAGE 2: Feature Engineering & Selection ---")
    selected_features, df_rank = run_feature_selection(X_train, y_train, top_k=8)
    df_rank.to_csv(os.path.join(output_dir, "result1_feature_selection.csv"), index=False)

    # STAGE 3: Phase 1 Signature Engine Setup
    print("\n--- STAGE 3: Phase 1 Signature Engine Initialization ---")
    sig_engine = SignatureEngine()

    # STAGE 4: Phase 2 Machine Learning Models Training
    print("\n--- STAGE 4: Phase 2 Machine Learning Classifiers Training ---")
    X_train_sel = X_train[selected_features]
    X_test_sel = X_test[selected_features]
    trained_models, ml_metrics_df = train_and_evaluate_models(X_train_sel, y_train, X_test_sel, y_test)
    ml_metrics_df.to_csv(os.path.join(output_dir, "result2_classifier_benchmark.csv"), index=False)

    # STAGE 5: Hybrid IDS Integration
    print("\n--- STAGE 5: Hybrid Engine Integration ---")
    best_ml_model = trained_models['Random Forest']
    hybrid_ids = HybridIDS(sig_engine, best_ml_model, selected_features)

    # STAGE 6: Evaluate All Configurations
    print("\n--- STAGE 6: System Configurations Comparative Benchmarking ---")
    
    # Config 1: Signature Only
    sig_mask, sig_preds, sig_time_ms = sig_engine.predict(X_test)
    sig_metrics = evaluate_system_performance(y_test, sig_preds, sig_time_ms / len(X_test), "Signature Only")

    # Config 2: ML Anomaly Only
    t_ml_start = time.perf_counter()
    ml_preds = best_ml_model.predict(X_test_sel)
    ml_time_ms = (time.perf_counter() - t_ml_start) * 1000.0
    ml_metrics = evaluate_system_performance(y_test, ml_preds, ml_time_ms / len(X_test), "ML Anomaly Only")

    # Config 3: Hybrid IDS (Phase 1 + Phase 2)
    hybrid_preds, breakdown = hybrid_ids.predict_stream(X_test)
    hybrid_metrics = evaluate_system_performance(y_test, hybrid_preds, breakdown['avg_latency_ms'], "Hybrid IDS ★")

    hybrid_comparison_df = pd.DataFrame([
        {
            'Configuration': 'Signature Only',
            'Accuracy': sig_metrics['Accuracy'],
            'Detection Rate': sig_metrics['Recall (DR)'],
            'FPR': sig_metrics['FPR'],
            'Avg Latency': sig_metrics['Avg Latency (ms)'],
            'Zero-Day Detection': 'No'
        },
        {
            'Configuration': 'ML Anomaly Only',
            'Accuracy': ml_metrics['Accuracy'],
            'Detection Rate': ml_metrics['Recall (DR)'],
            'FPR': ml_metrics['FPR'],
            'Avg Latency': ml_metrics['Avg Latency (ms)'],
            'Zero-Day Detection': 'Yes'
        },
        {
            'Configuration': 'Hybrid IDS (Proposed)',
            'Accuracy': hybrid_metrics['Accuracy'],
            'Detection Rate': hybrid_metrics['Recall (DR)'],
            'FPR': hybrid_metrics['FPR'],
            'Avg Latency': hybrid_metrics['Avg Latency (ms)'],
            'Zero-Day Detection': 'Yes'
        }
    ])
    hybrid_comparison_df.to_csv(os.path.join(output_dir, "result3_hybrid_performance.csv"), index=False)

    resource_df = pd.DataFrame([
        {
            'System': 'Signature Only',
            'Avg CPU Load': sig_metrics['CPU Load (%)'],
            'Avg Memory (MB)': sig_metrics['Memory Footprint (MB)'],
            'Notes': 'Pure rule matching'
        },
        {
            'System': 'ML Anomaly Only',
            'Avg CPU Load': ml_metrics['CPU Load (%)'],
            'Avg Memory (MB)': ml_metrics['Memory Footprint (MB)'],
            'Notes': 'Full ML per packet'
        },
        {
            'System': 'Hybrid IDS (Proposed)',
            'Avg CPU Load': hybrid_metrics['CPU Load (%)'],
            'Avg Memory (MB)': hybrid_metrics['Memory Footprint (MB)'],
            'Notes': 'ML bypassed for known'
        }
    ])
    resource_df.to_csv(os.path.join(output_dir, "result4_resource_consumption.csv"), index=False)

    # STAGE 7: Zero-Day Attack Simulation Analysis
    print("\n--- STAGE 7: Zero-Day Attack Simulation ---")
    
    # Categorical detection comparison for Reconnaissance, DoS, DDoS, Theft
    cat_names = {1: 'DoS', 2: 'DDoS', 3: 'Reconnaissance', 4: 'Theft'}
    zero_day_results = []
    
    for cat_id, cat_name in cat_names.items():
        idx = (cat_test == cat_id)
        if idx.sum() > 0:
            sig_recall = recall_score(y_test[idx], sig_preds[idx], zero_division=0)
            hybrid_recall = recall_score(y_test[idx], hybrid_preds[idx], zero_division=0)
            zero_day_results.append({
                'Attack Type': cat_name,
                'Signature Only Recall': f"{sig_recall*100:.2f}%",
                'Hybrid IDS Recall': f"{hybrid_recall*100:.2f}%"
            })
            
    zero_day_df = pd.DataFrame(zero_day_results)
    zero_day_df.to_csv(os.path.join(output_dir, "result5_zeroday_detection.csv"), index=False)

    # STAGE 8: Visualizations & Summary Report Generation
    print("\n--- STAGE 8: Generating Publication Visualizations & Final Summaries ---")
    generate_all_visualizations(df_rank, ml_metrics_df, trained_models, hybrid_comparison_df, resource_df, X_test_sel, y_test, output_dir)

    print("\n" + "="*75)
    print("  EXECUTIVE EXPERIMENTAL RESULTS SUMMARY")
    print("="*75)
    print("\n1. FEATURE SELECTION SUMMARY:")
    print(df_rank.to_string(index=False))
    
    print("\n2. CLASSIFIER BENCHMARK SUMMARY:")
    print(ml_metrics_df.to_string(index=False))
    
    print("\n3. HYBRID IDS PERFORMANCE:")
    print(hybrid_comparison_df.to_string(index=False))
    
    print("\n4. RESOURCE CONSUMPTION SUMMARY:")
    print(resource_df.to_string(index=False))
    
    print("\n5. ZERO-DAY DETECTION SIMULATION:")
    print(zero_day_df.to_string(index=False))
    print("="*75)
    print(f"\n[+] Pipeline completed successfully. All artifacts stored in: {os.path.abspath(output_dir)}")

if __name__ == '__main__':
    run_main_pipeline()
